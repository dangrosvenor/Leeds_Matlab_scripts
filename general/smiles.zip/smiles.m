%smiles parser

str1='CC(C(CC(=O)C(O)=O)CO)(C)O';

nopen=findstr('(',str1);

nclose=findstr(')',str1);


str_0th_brack=str1(1:nopen(1)-1);
 go=1;
 i=0;
 while go==1
    i=i+1;
    a=length(find(nopen<nclose(i)));
    if a==i
        go=0;
    end
    
end

str_0th_brack = [str_0th_brack str1(nclose(i)+1:end)]

str_1st_brack = str1(nopen(1)+1:nclose(i)-1)

    
