function [iz_1,iz_2]=findheight(z,z1,z2)
%function [iz1,iz2]=findheight(z,z1,z2) - z=array z1 and z2 are lower and upper bounds
for i=1:length(z1)
    iz1=find(z<=z1(i));
    [temp iz]=max(z(iz1));
    iz_1(i)=iz1(iz);

if nargin==3
    iz2=find(z>=z2(i));
    [temp iz]=min(z(iz2));
    iz_2(i)=iz2(iz);
end

end
